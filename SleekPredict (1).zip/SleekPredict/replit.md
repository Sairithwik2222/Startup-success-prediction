# Startup Success Predictor

## Overview

A machine learning-powered web application that predicts startup success probability based on multiple factors including location, industry, funding, team size, and business model. The application uses an ensemble of ML models to generate predictions and provides interactive dashboards for analyzing historical predictions. Built with Streamlit for rapid UI development and scikit-learn for machine learning capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Web Framework**: Streamlit-based single-page application with two main views:
- **Prediction View**: Multi-step form collecting startup information (location, industry, funding, team details)
- **Dashboard View**: Analytics interface displaying prediction history with filters and visualizations

**UI Design Pattern**: 
- Custom CSS styling with animated gradient backgrounds for visual polish
- Wide layout mode maximizing screen real estate
- Glassmorphism design (backdrop blur, semi-transparent panels)
- Interactive visualizations using Plotly for charts, graphs, and gauge displays
- Sidebar navigation for view switching

**Rationale**: Streamlit chosen to enable rapid development of data-centric applications using pure Python. Eliminates need for separate frontend framework while providing built-in state management and reactive UI updates. Trade-off: less control over UI customization compared to React/Vue, but significantly faster development time for data science applications.

### Machine Learning Architecture

**Ensemble Prediction System**: Multi-model approach for robust predictions
- Four scikit-learn classifiers: Logistic Regression, Decision Tree, Random Forest, SVM
- Weighted averaging of model predictions for final success probability
- Individual model accuracy tracking via cross-validation
- Feature importance extraction for explainability

**Training Data Strategy**: Synthetic data generation
- Generates 1000+ training samples with realistic correlation patterns
- Success probability calculated from weighted combination of normalized features
- Random noise injection to simulate real-world variability
- Fixed random seed for reproducibility

**Feature Engineering Pipeline**:
- **Financial**: Normalized funding amounts (0-1 scale), adjusted for currency/region
- **Geographic**: Population density, GDP index, internet penetration (all 0-1 normalized)
- **Business**: Team size ratio, company age inverse, industry scores, business model ratings
- **Competitive**: Market saturation factors, competition indices
- StandardScaler normalization for model input consistency

**Rationale**: Ensemble approach mitigates individual model weaknesses and provides confidence intervals. Synthetic data necessary due to lack of publicly available startup outcome datasets. Multiple models allow comparison of different algorithmic approaches (linear vs tree-based vs kernel methods).

### Data Management

**ORM Layer**: SQLAlchemy with declarative base
- Environment-based database selection: SQLite for local development, PostgreSQL for production
- Single `Prediction` model storing all prediction records
- Automatic table creation via `Base.metadata.create_all()`
- Session management integrated with Streamlit's execution model

**Database Schema**: Denormalized single-table design
```
Prediction table:
- Core fields: id, created_at, startup_name, industry, business_model
- Location hierarchy: country, state, city, locality
- Metrics: team_size, founding_year, funding_amount, currency_code/symbol
- Results: success_probability, confidence_interval
- JSON columns: industry_metrics, model_predictions, model_accuracies, feature_importance
```

**Query Patterns**:
- Fetch all predictions for dashboard rendering
- Filter predictions by date range, industry, country, funding bracket
- Count-based queries for metrics/statistics

**Rationale**: Single-table design simplifies queries and avoids JOIN overhead for read-heavy analytics workload. JSON columns provide flexibility for storing variable industry-specific data and ML model outputs without schema migrations. SQLAlchemy chosen for database portability and Pythonic query interface.

### Reference Data Architecture

**Static Data Modules**: Hardcoded reference data in Python modules
- **location_data.py**: Hierarchical geographic data (countries → states → cities → localities)
  - Uses `pycountry` library for country enumeration
  - Extensive hardcoded mappings for Indian states/cities
  - US states with major cities
- **currency_data.py**: Country-to-currency mappings (45+ countries)
  - Currency code, symbol, and full name
  - Used for funding amount normalization and display formatting
- **industry_metrics.py**: Business model definitions and industry-specific input fields
  - 9 business model types with descriptions/examples
  - Industry-specific metric configurations (truncated in files)

**Rationale**: Static reference data approach chosen over database normalization for simplicity and performance. Geographic/currency data changes infrequently and benefits from in-memory access. Trade-off: harder to update reference data (requires code changes) but eliminates database queries for every form render.

## External Dependencies

### Core Framework Dependencies
- **Streamlit**: Web application framework for Python-based data apps
- **Plotly**: Interactive charting library (graph_objects and express modules)
- **Pandas**: Data manipulation and DataFrame operations
- **NumPy**: Numerical computing for array operations

### Machine Learning Stack
- **scikit-learn**: ML algorithms (RandomForest, DecisionTree, LogisticRegression, SVM)
  - StandardScaler for feature normalization
  - cross_val_score for model validation

### Database Layer
- **SQLAlchemy**: ORM and database toolkit
  - Supports SQLite (local) and PostgreSQL (production)
  - Declarative base for model definitions
  - Session management for transactions

### Reference Data
- **pycountry**: ISO country database for country enumeration

### Data Storage
- **SQLite**: Default local development database (file-based)
- **PostgreSQL**: Production database (connection via environment variable `DATABASE_URL`)

### Deployment Considerations
- Application expects `DATABASE_URL` environment variable for PostgreSQL connection
- Falls back to SQLite (`startup_predictions.db`) if variable not set
- Streamlit configuration via `st.set_page_config()` for page metadata